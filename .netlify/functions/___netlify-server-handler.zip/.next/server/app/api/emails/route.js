"use strict";(()=>{var e={};e.id=959,e.ids=[959],e.modules={399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},2048:e=>{e.exports=require("fs")},2615:e=>{e.exports=require("http")},8791:e=>{e.exports=require("https")},5315:e=>{e.exports=require("path")},8621:e=>{e.exports=require("punycode")},6162:e=>{e.exports=require("stream")},7360:e=>{e.exports=require("url")},1764:e=>{e.exports=require("util")},2623:e=>{e.exports=require("worker_threads")},1568:e=>{e.exports=require("zlib")},7561:e=>{e.exports=require("node:fs")},4492:e=>{e.exports=require("node:stream")},2477:e=>{e.exports=require("node:stream/web")},3002:(e,t,o)=>{o.r(t),o.d(t,{originalPathname:()=>x,patchFetch:()=>b,requestAsyncStorage:()=>f,routeModule:()=>h,serverHooks:()=>y,staticGenerationAsyncStorage:()=>g});var a={};o.r(a),o.d(a,{GET:()=>p,PATCH:()=>u,POST:()=>d});var n=o(9303),r=o(8716),i=o(670),s=o(7070),l=o(728),c=o(5563);async function p(e){try{let{searchParams:t}=new URL(e.url),o=t.get("kolId"),a=t.get("status"),n={};o&&(n.kolId=o),a&&(n.status=a);let r=await l._.email.findMany({where:n,orderBy:{createdAt:"desc"},include:{kol:!0}});return s.NextResponse.json(r)}catch(e){return s.NextResponse.json({error:"Failed to fetch emails"},{status:500})}}async function u(e){try{let{id:t,status:o}=await e.json();if(!t||!o)return s.NextResponse.json({error:"Missing id or status"},{status:400});let a=await l._.email.update({where:{id:t},data:{status:o}});return s.NextResponse.json(a)}catch(e){return s.NextResponse.json({error:"Failed to update email status"},{status:500})}}let m="You are a text generator. You generate ONLY the final message text. You NEVER output anything except the message itself. No thinking. No reasoning. No word count. No explanation. No notes. No drafts. No preamble. No commentary. Just the message. If you output anything other than the message itself, it is WRONG.";async function d(e){try{let t;let{kolId:o,kolName:a,kolProfile:n,language:r,cooperationType:i,tone:p,brandInfo:u,channel:d}=await e.json(),h=null;if(o)try{h=await l._.kOL.findUnique({where:{id:o}})}catch{}let f=h?.name||a||"KOL",g=h?.notes||n||"",y=h?.platform||"",x=h?.followers||0,b=h?.region||"",O=h?.niche||"",w={gift:"Gift (free products for testing/use)",paid:"Paid collaboration (equipment return + payment per video)",commission:"Commission-based",pending:"To be discussed / Pending"}[i]||i||"Gift (free products for testing/use)",L=d||"email",N=!1;if("whatsapp"===L)t=function(e,t,o,a,n,r,i,s,l){let c=e.match(/\(([^)]+)\)/),p=c?c[1]:e.split(/\s+/)[0],u="Portuguese"===l?"Portugu\xeas":"Spanish"===l?"Espa\xf1ol":"English";return[{role:"system",content:m},{role:"user",content:`Generate a WhatsApp message in ${l} (${u}). The message must be written ENTIRELY in ${l}.

Recipient: ${p}
Their platform: ${t}
Their region: ${n||"Latin America"}

The message must have exactly this structure (with blank lines between sections):

Line 1: Oi, ${p}! 👋

Line 2: Vi seu conte\xfado sobre energia solar e fiquei impressionado com a clareza.

Line 3: (empty)

Line 4: A Ktech Solar \xe9 uma fabricante chinesa de inversores solares e sistemas fotovoltaicos, especializada em inversores h\xedbridos e off‑grid com MPPT integrado, prote\xe7\xe3o IP65 e compatibilidade com baterias LiFePO4.

Line 5: (empty)

Line 6: Gostar\xedamos de propor uma parceria com duas modalidades \xe0 sua escolha:

Line 7: Op\xe7\xe3o A: Enviamos o equipamento de presente, sem compromisso de pagamento.

Line 8: Op\xe7\xe3o B: Pagamos por cada v\xeddeo ou post produzido com o nosso inversor.

Line 9: (empty)

Line 10: Em ambos os casos, pedimos apenas um feedback sincero e, se gostar, um v\xeddeo mostrando o produto em a\xe7\xe3o.

Line 11: (empty)

Line 12: Topa receber mais detalhes pelo WhatsApp? 😊

Line 13: (empty)

Line 14: ${"Portuguese"===l?"Abra\xe7o!":"Spanish"===l?"Saludos!":"Cheers!"}

Line 15: Eaea from Ktech Solar

Line 16: WhatsApp: +86-18914111136

IMPORTANT: Output ONLY the final message text above. Do NOT add any thinking, reasoning, word count, explanation, or any other text. The message must be in ${l} (${u}). Start directly with "Oi, ${p}!" and end with the WhatsApp number.`}]}(f,y,0,0,b,0,0,0,r),N=!0;else if("instagram"===L)t=function(e,t,o,a,n,r,i,s,l){let c=e.match(/\(([^)]+)\)/),p=c?c[1]:e.split(/\s+/)[0];return[{role:"system",content:m},{role:"user",content:`Generate an Instagram DM in ${l} (${"Portuguese"===l?"Portugu\xeas":"Spanish"===l?"Espa\xf1ol":"English"}). Output ONLY the message text.

Recipient: ${p}
Platform: ${t}
Region: ${n||"Latin America"}

Structure (with blank lines between sections):

Line 1: Oi, ${p}! 👋🌞

Line 2: Adorei seu conte\xfado sobre energia solar!

Line 3: (empty)

Line 4: Sou da Ktech Solar, fabricante chinesa de inversores solares. Adorar\xedamos enviar um equipamento para voc\xea testar!

Line 5: (empty)

Line 6: Quer receber mais detalhes? 😊

Line 7: (empty)

Line 8: Eaea from Ktech Solar 🌞

IMPORTANT: Output ONLY the message. No thinking, no reasoning, no word count, no explanation. Start with "Oi, ${p}!" and end with "Eaea from Ktech Solar 🌞". Write entirely in ${l}.`}]}(f,y,0,0,b,0,0,0,r),N=!0;else{let e=`You are a professional international marketing specialist writing a KOL outreach email. Write a COMPLETE, well-structured email in ${r||"English"}. Do NOT truncate or cut off mid-sentence.

KOL Information:
- Name: ${f}
- Platform: ${y}
- Followers: ${x}
- Niche: ${O||"Solar Energy"}
- Region: ${b||"Not specified"}
- Profile Notes: ${g||"N/A"}

Brand Information: ${u||"Ktech Solar - solar inverter manufacturer"}

Cooperation Type: ${w}

Tone: ${p||"Professional yet warm"}

EMAIL STRUCTURE (follow all sections in order):

1. SUBJECT LINE: The VERY FIRST line must be "Subject: " followed by a personalized, sincere subject line that feels authentic and specific to THIS KOL. Do NOT use generic subjects like "Partnership Opportunity" or "Collaboration". Instead, reference something specific about them — their content, their region, or a genuine compliment. Examples:
   - Portuguese: "Subject: Seus v\xeddeos sobre instala\xe7\xe3o solar me impressionaram — proposta de parceria"
   - Spanish: "Subject: Me encant\xf3 tu contenido sobre energ\xeda solar — propuesta de colaboraci\xf3n"
   - English: "Subject: Loved your recent solar installation video — collaboration idea for ${f}"
   Make the subject feel like it was written specifically for them, not a template.

2. GREETING: Address the KOL by name warmly.

3. OPENING (2-3 sentences): Mention that you recently discovered their channel/content and were genuinely impressed. Reference their content style naturally. Make it feel personal and authentic, not generic.

4. BRAND INTRODUCTION (3-4 sentences): Introduce Ktech Solar as a Chinese manufacturer of solar inverters and photovoltaic energy systems. Mention key product features: hybrid and off-grid inverters, integrated MPPT, IP65 protection, LiFePO4 battery compatibility. Mention the website: https://www.ktechsolar.com/

5. WHY THEM (2-3 sentences): Explain specifically why this KOL is a great fit — reference their platform, content style, audience, and region. Show that you've done your research.

6. COLLABORATION PROPOSAL (3-4 sentences): Clearly explain what we offer based on the cooperation type:
   - If Gift: We send free inverters/equipment for them to test and use in their projects, no payment required.
   - If Paid: Equipment for content creation + payment per video/post.
   - If Commission: Revenue sharing partnership.
   - If Pending: Open to discussion.
   Also mention: special installer pricing, direct technical support from our engineering team.

7. WHAT WE ASK (2-3 sentences): 1 post or Reel showing the equipment in a real installation or technical review. 1 mention in Stories (optional).

8. CALL TO ACTION (2 sentences): Suggest connecting via WhatsApp or Google Meet. Ask for their preferred time.

9. CLOSING: Warm professional sign-off. Use: "Abra\xe7o," for Portuguese, "Saludos," for Spanish, "Best regards," for English.
   Sign as: Eaea, Overseas Media Relations Specialist, Ktech Solar
   Include: WhatsApp: +86-18914111136 | Email: eaea@ktechenergy.com

CRITICAL: Write the COMPLETE email. Do not stop mid-sentence. Every section above must be included. The email should be approximately 250-400 words. Write entirely in ${r||"English"} with proper special characters (\xe7, \xe3, \xf5, \xe9, \xed, \xf3, \xfa, \xf1, etc.).`;t=[{role:"user",content:e}]}let S=N?"google/gemma-4-26b-a4b-it:free":process.env.OPENAI_MODEL||"nvidia/nemotron-3-super-120b-a12b:free",v=await c.fr.chat.completions.create({model:S,messages:t,temperature:"email"===L?.7:.2,max_tokens:"email"===L?2e3:500}),E=v.choices[0]?.message?.content||"";"email"!==L&&(E=function(e,t){let o=e;o=(o=o.replace(/<think>[\s\S]*?<\/think>/gi,"")).replace(/^(Here is|Below is|This is|Sure!|Okay!|Alright!|Of course!|Certainly!|Absolutely!|No problem!|I'd be happy to)[\s\S]*?\n\n/gim,"");let a="",n=1/0;for(let e of[/(?:^|\n)\s*((?:Oi|Hola|Hey|Hi|Olá|Hello|Bună|Ciao|Salut|Buenos|Buenas|Ei|Yo)[\s\S]*)/i]){let t=o.match(e);t&&void 0!==t.index&&t.index<n&&(n=t.index,a=t[1].trim())}for(let e of(a&&n<.6*o.length&&(o=a),[/\n(?:Word count|Words:|Total words|Word total|Count:|Total:|Nota:|Note:|Observação|Observations|Summary|Resumo|Análise|Analysis|---)/i,/\n(?:This message|The message|Above|Espero que|Es message|Ce message|Dieses Nachricht)/i,/\n\d+ words/i])){let t=o.match(e);t&&void 0!==t.index&&(o=o.substring(0,t.index).trim())}return o=o.replace(/\n{3,}/g,"\n\n").trim()}(E,0));let T=E.match(/Subject:\s*(.+)/i),P=T?T[1].trim():"Collaboration Opportunity",A="email"===L?E.replace(/Subject:\s*.+\n\n?/i,""):E,I=null,R=o||null;if(!R)try{let e=await l._.kOL.findFirst({select:{id:!0}});e&&(R=e.id)}catch{}if(R)try{I=await l._.email.create({data:{kolId:R,subject:P,body:A,language:r||"English",cooperationType:i||"gift",tone:p||"Professional yet warm",channel:L,status:"Draft"}})}catch(e){console.warn("Failed to save to database:",e)}return s.NextResponse.json({...I||{},id:I?.id||`temp-${Date.now()}`,subject:P,body:A,content:E,language:r||"English",cooperationType:i||"gift",channel:L,status:"Draft"},{status:201})}catch(e){return console.error("Generation error:",e),s.NextResponse.json({error:e.message||"Failed to generate"},{status:500})}}let h=new n.AppRouteRouteModule({definition:{kind:r.x.APP_ROUTE,page:"/api/emails/route",pathname:"/api/emails",filename:"route",bundlePath:"app/api/emails/route"},resolvedPagePath:"C:\\Users\\T14\\Desktop\\市场部\\ai-kol-assistant\\src\\app\\api\\emails\\route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:f,staticGenerationAsyncStorage:g,serverHooks:y}=h,x="/api/emails/route";function b(){return(0,i.patchFetch)({serverHooks:y,staticGenerationAsyncStorage:g})}},5563:(e,t,o)=>{o.d(t,{Nt:()=>n,fr:()=>a});let a=new(o(4214)).ZP({apiKey:process.env.OPENAI_API_KEY,baseURL:process.env.OPENAI_BASE_URL||"https://api.openai.com/v1"});async function n(e){return JSON.parse((await a.chat.completions.create({model:"openai/gpt-4o",messages:[{role:"system",content:`You are an expert marketing analyst specializing in KOL (Key Opinion Leader) evaluation. 
        Analyze the given KOL profile and provide structured insights in JSON format with these fields:
        - contentStyle: description of their content style and tone
        - audienceProfile: inferred audience demographics and interests
        - engagementQuality: assessment of their engagement (low/medium/high + reasoning)
        - brandFitScore: score from 1-10 for solar/tech brand partnership potential
        - recommendations: array of actionable collaboration suggestions
        - riskFactors: array of potential risks or concerns`},{role:"user",content:`Analyze this KOL:
        Name: ${e.name}
        Platform: ${e.platform}
        Followers: ${e.followers.toLocaleString()}
        Content: ${e.contentDescription}`}],response_format:{type:"json_object"}})).choices[0].message.content||"{}")}},728:(e,t,o)=>{o.d(t,{_:()=>n});let a=require("@prisma/client"),n=globalThis.prisma??new a.PrismaClient}};var t=require("../../../webpack-runtime.js");t.C(e);var o=e=>t(t.s=e),a=t.X(0,[948,972,214],()=>o(3002));module.exports=a})();